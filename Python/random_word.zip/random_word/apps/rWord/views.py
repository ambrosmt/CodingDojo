from django.shortcuts import render, HttpResponse, redirect


