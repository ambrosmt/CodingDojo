'''
4)

migrate to folder in cmd

run\ python manage.py startapp (name new app)

'''