'''
2)

Make an apps folder and initialize (3) done automatically)

'''