'''

Main file for project

home for settings.py and base url directory

'''