from django.shortcuts import render, HttpResponse, redirect

#def index(request):
    #functions
    #return 